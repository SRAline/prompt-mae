# 🧬 Prompt Mãe LYDS - Documentação

Este é o índice central para utilizar o Prompt Base da LYDS em geração de agentes via LLMs (assistentes de IA).

## Conteúdo

- [Prompt Base em .txt](./Prompt-Mae-LYDS.txt)
- [Prompt Base formatado (.md)](./PROMPT-MAE.md)
- [Exemplos XML prontos](./XMLs/)
- [README do projeto](./README.md)
